
/*
#ifndef _Movil_IoT_h
#define _Movil_IoT_h
*/

//#include "Arduino.h"
#include "BlynkEdgent.h"

/*
bool Arriba = 0;//
char Movimiento = 'A';

BLYNK_WRITE(V5) {
  Arriba = param.asInt();
  if (Arriba) {
    Movimiento = 'A';
    Serial.println("ok");
  }
  else {
    Movimiento = 'A';
    Serial.println("ok1");
  }
}
*/

void Ls_Leds(int ms);

/*
#endif*/
